# modern-automated-dcf

[![GitHub Stars](https://img.shields.io/github/stars/Nico-Rode/modern-automated-dcf?style=social)](https://github.com/Nico-Rode/modern-automated-dcf/stargazers)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/automated-dcf)](https://pypi.org/project/automated-dcf/)
[![PyPI](https://img.shields.io/pypi/v/automated-dcf)](https://pypi.org/project/automated-dcf/)
[![Build Status](https://github.com/Nico-Rode/modern-automated-dcf/actions/workflows/ci.yml/badge.svg)](https://github.com/Nico-Rode/modern-automated-dcf/actions/workflows/ci.yml)

![DCF Plot Screenshot](AAPL_DCF_Plot.png)

## About

`modern-automated-dcf` is a robust and modern Python library designed for performing Discounted Cash Flow (DCF) valuations of public companies. It automates the process of fetching financial data, calculating key metrics, projecting future cash flows, and determining intrinsic value. This project aims to provide a reliable and easy-to-use tool for investors, analysts, and students.

## Features

*   **Reliable Data Sources**: Integrates with `yfinance` (primary) to fetch historical financial data (income statement, balance sheet, cash flow) directly from Yahoo Finance, avoiding fragile web scraping methods.
*   **Comprehensive DCF Model**: Calculates Free Cash Flow (FCF), Weighted Average Cost of Capital (WACC), Terminal Value, Enterprise Value, and Equity Value.
*   **Future Cash Flow Projections**: Projects FCF for 5-10 years based on user-defined growth assumptions.
*   **Key Financial Metrics**: Provides functions to compute essential financial metrics like Revenue, EBIT, and FCF.
*   **Robustness**: Includes safeguards for handling missing data, validating against reported numbers, and managing data units (millions/thousands).
*   **Output Formats**: Generates professional Excel reports with DCF tables, assumptions, and sensitivity analysis. Also provides CSV output and a simple plot of historical and projected FCF using `matplotlib`.
*   **Pip-installable Library**: Easily installable via `pip` for seamless integration into other Python projects.
*   **Command-Line Interface (CLI)**: Offers a user-friendly CLI for quick valuations without writing Python code.
*   **Modular Design**: Designed with modular functions for easy extension and maintenance.
*   **Testing**: Includes a `pytest` suite for ensuring accuracy and reliability.

## Quick Start

### Installation

```bash
pip install automated-dcf
```

### CLI Usage

To run a DCF analysis for a ticker (e.g., AAPL) and generate an Excel report with a plot:

```bash
dcf AAPL --output excel
```

### Python Library Usage

```python
from automated_dcf import DCFModel

# Initialize the model with a ticker symbol
ticker = 'MSFT'
dcf_model = DCFModel(ticker)

# Fetch financial data
dcf_model.fetch_data()

# Run the DCF valuation with custom parameters
results = dcf_model.run_dcf(years=7, growth_rate=0.06, discount_rate=0.09, perpetual_growth=0.02)

# Print results
print(f"Intrinsic Value for {ticker}: ${results['intrinsic_value']:.2f}")
print(f"Current Price: ${results['current_price']:.2f}")
print(f"Upside: {results['upside']*100:.2f}%")

# Export to Excel and generate plot
dcf_model.export_to_excel(f"{ticker}_DCF_Analysis.xlsx")
dcf_model.plot_results(f"{ticker}_DCF_Plot.png")
```

## Dependencies

The project relies on the following Python packages:

*   `yfinance`: For fetching financial data.
*   `pandas`: For data manipulation and analysis.
*   `numpy`: For numerical operations.
*   `numpy-financial`: For financial functions.
*   `openpyxl`: For reading and writing Excel files.
*   `matplotlib`: For plotting and visualizations.
*   `click`: For building the command-line interface.
*   `pytest`: For running unit tests.

These dependencies are listed in `requirements.txt` and `pyproject.toml`.

## Usage Examples

### Single Ticker Valuation

```bash
dcf GOOG --years 10 --growth 0.04 --discount 0.08 --output excel
```

This command will perform a 10-year DCF projection for Google (GOOG) with a 4% growth rate and an 8% discount rate, outputting the results to an Excel file and a plot.

### Batch Valuation (Conceptual - requires scripting)

For batch processing multiple tickers, you can write a simple Python script:

```python
from automated_dcf import DCFModel
import pandas as pd

tickers = ["AAPL", "MSFT", "GOOG"]
all_results = []

for ticker in tickers:
    try:
        model = DCFModel(ticker)
        model.fetch_data()
        results = model.run_dcf()
        all_results.append(results)
        model.export_to_excel(f"{ticker}_DCF_Analysis.xlsx")
        model.plot_results(f"{ticker}_DCF_Plot.png")
    except Exception as e:
        print(f"Error processing {ticker}: {e}")

final_df = pd.DataFrame(all_results)
final_df.to_csv("batch_dcf_results.csv", index=False)
print("Batch DCF results saved to batch_dcf_results.csv")
```

## DCF Methodology

The Discounted Cash Flow (DCF) model estimates the intrinsic value of an asset based on its expected future cash flows. The core steps involve:

1.  **Forecasting Free Cash Flow (FCF)**: Projecting the cash generated by the company after accounting for capital expenditures. This model forecasts FCF for a specified number of years (e.g., 5-10 years) based on a growth rate.
2.  **Calculating Weighted Average Cost of Capital (WACC)**: Determining the average rate of return a company expects to pay to finance its assets. WACC is used as the discount rate to bring future cash flows to their present value. It considers the cost of equity (using CAPM) and the after-tax cost of debt.
3.  **Estimating Terminal Value (TV)**: Calculating the value of the company's cash flows beyond the explicit forecast period. This is typically done using the Gordon Growth Model, assuming a perpetual growth rate.
4.  **Discounting Future Cash Flows**: Summing the present values of the projected FCFs and the Terminal Value to arrive at the Enterprise Value.
5.  **Calculating Equity Value**: Adjusting the Enterprise Value by adding cash and subtracting debt to get the Equity Value.
6.  **Determining Intrinsic Value Per Share**: Dividing the Equity Value by the number of outstanding shares.

For a deeper understanding of DCF methodology, refer to works by Aswath Damodaran [1].

## Limitations & Disclaimer

*   **Assumptions**: DCF models are highly sensitive to assumptions (growth rates, discount rates, perpetual growth). Small changes can lead to significant variations in intrinsic value.
*   **Data Accuracy**: While `yfinance` is generally reliable, financial data can sometimes be inconsistent or delayed. Always cross-verify with official company reports.
*   **Future Uncertainty**: Financial projections are inherently uncertain and subject to market conditions, economic changes, and company-specific events.
*   **Not Financial Advice**: This tool is for educational and analytical purposes only and should not be considered financial advice. Always conduct your own due diligence before making investment decisions.

## Contributing

Contributions are welcome! Please feel free to submit pull requests or open issues on the GitHub repository.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## References

[1] Damodaran Online: [http://pages.stern.nyu.edu/~adamodar/](http://pages.stern.nyu.edu/~adamodar/)
